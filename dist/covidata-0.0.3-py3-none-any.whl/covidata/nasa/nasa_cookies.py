cookies = {
        'AppAuth':'4a77c196-45e5-4e82-9582-401a8126b239',
        '_gid':'GA1.3.348748395.1590891905',
        #'_gid':'GA1.4.112583249.1590891991',
        #'_gid':'GA1.2.348748395.1590891905',
        #'_ga':'GA1.2.1850151255.1590891905',
        #'_ga':'GA1.2.270272746.1590891991',
        '_gat_GSA_ENOR0':'1',
        '_urs-gui_session':'7c8cd1ce2ec75a12ee2ea617df6f9e4d',
        #'_ga':'GA1.3.1850151255.1590891905',
        'urs_user_already_logged':'yes',
        #'_gid':'GA1.2.112583249.1590891991',
        '_gat_UA-62340125-2':'1',
        'urs_guid_ops':'8b20175d-8978-47b1-8d93-de886823ca09',
        #'_ga':'GA1.4.270272746.1590891991',
        }

headers = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36'}

login_data = {
        'utf8': '✓',
        'username': 'vvannini',
        'password': 'SpaceApps2020',
        'client_id': 'YQOhivHfMTau88rjbMOVyg',
        'redirect_uri': 'https://daac.ornl.gov/cgi-bin/urs/urs_logon_proc.pl',
        'response_type': 'code',
        'state': 'https://daac.ornl.gov/',
        'stay_in': '1',
        'commit': 'Log in',
}
