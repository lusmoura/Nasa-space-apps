headers = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.92 Safari/537.36'}

login_data = {
        'utf8': '✓',
        'client_id': 'YQOhivHfMTau88rjbMOVyg',
        'redirect_uri': 'https://daac.ornl.gov/cgi-bin/urs/urs_logon_proc.pl',
        'response_type': 'code',
        'state': 'https://daac.ornl.gov/',
        'stay_in': '1',
        'commit': 'Log in',
}
